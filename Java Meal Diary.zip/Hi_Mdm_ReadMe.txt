Hi mdm, to run the food diary program, locate the jar. file under: Food_Diary\dist

Thanks mdm.