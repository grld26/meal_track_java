package food_diary;
import java.util.Scanner;
import javax.swing.JOptionPane;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

/**
 *
 * @author geral
 */

//Class Extras 
public class Extras extends javax.swing.JFrame{
       
    JFrame f = new JFrame();//creating instance of JFrame  
    
    
    /**
     * Creates new form Extras
     */
    public Extras() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jButton6 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        lb1 = new javax.swing.JLabel();
        lb2 = new javax.swing.JLabel();
        lbResult = new javax.swing.JLabel();
        txtHeight = new javax.swing.JTextField();
        txtWeight = new javax.swing.JTextField();
        btnResult = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        menubar1 = new javax.swing.JMenuBar();
        menu1 = new javax.swing.JMenu();
        menuhomepage1 = new javax.swing.JMenuItem();
        menuadd1 = new javax.swing.JMenuItem();
        menuview1 = new javax.swing.JMenuItem();
        menuedit1 = new javax.swing.JMenuItem();
        menudelete1 = new javax.swing.JMenuItem();
        menusearch1 = new javax.swing.JMenuItem();
        menuextras1 = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(204, 153, 255));

        jButton6.setFont(new java.awt.Font("Yu Gothic UI", 1, 12)); // NOI18N
        jButton6.setText("Logout");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 28)); // NOI18N
        jLabel1.setText("Extras");

        lb1.setText("Your height (metres): ");

        lb2.setText("Your weight (kg):");

        lbResult.setText("Result:");

        txtHeight.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtHeightActionPerformed(evt);
            }
        });

        txtWeight.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtWeightActionPerformed(evt);
            }
        });

        btnResult.setText("Calculate BMI");
        btnResult.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnResultActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Tahoma", 2, 11)); // NOI18N
        jLabel2.setText("**this BMI calculator does not reflect an entirely accurate result according to your gender and age");

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel3.setText("Calculate Your BMI");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(297, 297, 297)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lbResult)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lb1)
                            .addComponent(lb2))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtWeight, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtHeight, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(0, 248, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jButton6)
                        .addContainerGap())
                    .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(btnResult)
                        .addGap(304, 304, 304))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(313, 313, 313))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addGap(266, 266, 266))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel1)
                .addGap(48, 48, 48)
                .addComponent(jLabel3)
                .addGap(31, 31, 31)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtHeight, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lb1))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtWeight, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lb2))
                .addGap(18, 18, 18)
                .addComponent(lbResult)
                .addGap(15, 15, 15)
                .addComponent(btnResult)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 74, Short.MAX_VALUE)
                .addComponent(jLabel2))
        );

        f.add(lb1); //adding component in JFrame
        f.add(lb2); //adding component in JFrame
        f.add(lbResult); //adding component in JFrame

        menu1.setText("MENU");

        menuhomepage1.setText("Home");
        menuhomepage1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuhomepage1ActionPerformed(evt);
            }
        });
        menu1.add(menuhomepage1);

        menuadd1.setText("Add Meal Record");
        menuadd1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuadd1ActionPerformed(evt);
            }
        });
        menu1.add(menuadd1);

        menuview1.setText("View Meal Record");
        menuview1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuview1ActionPerformed(evt);
            }
        });
        menu1.add(menuview1);

        menuedit1.setText("Edit Meal Record");
        menuedit1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuedit1ActionPerformed(evt);
            }
        });
        menu1.add(menuedit1);

        menudelete1.setText("Delete Meal Record");
        menudelete1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menudelete1ActionPerformed(evt);
            }
        });
        menu1.add(menudelete1);

        menusearch1.setText("Search Meal Record");
        menusearch1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menusearch1ActionPerformed(evt);
            }
        });
        menu1.add(menusearch1);

        menuextras1.setText("Extras");
        menuextras1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuextras1ActionPerformed(evt);
            }
        });
        menu1.add(menuextras1);

        menubar1.add(menu1);

        setJMenuBar(menubar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        int n = JOptionPane.showConfirmDialog(null,"Confirm Logout","Logout from System",JOptionPane.YES_NO_OPTION);//pop up box asking confirmation to exit the application
        if(n==JOptionPane.YES_OPTION)//if yes is clicked
        {
            Login a = new Login();
            a.setVisible(true);
            this.setVisible(false); //current frame will be invisible
        }
    }//GEN-LAST:event_jButton6ActionPerformed

    private void txtWeightActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtWeightActionPerformed
        f.add(txtWeight); //adding component in JFrame 
    }//GEN-LAST:event_txtWeightActionPerformed
    
    private void btnResultActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnResultActionPerformed
        double weight=Double.parseDouble(txtWeight.getText());
                double height=Double.parseDouble(txtHeight.getText());  
                double bmi = weight /(height*height);
 
                 if (bmi < 18.5) {
                     lbResult.setText("underweight - BMI : "+bmi);
                 } else if (bmi < 25) {
                     lbResult.setText("normal - BMI : "+bmi);
                 } else if (bmi < 30) {
                     lbResult.setText("overweight - BMI : "+bmi);
                 } else {
                     lbResult.setText("obese - BMI : "+bmi);
                 }
    }//GEN-LAST:event_btnResultActionPerformed

    private void menuhomepage1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuhomepage1ActionPerformed
        //Direct to homepage
        Homepage homepage = new Homepage();//Constructor and object homepage
        homepage.setVisible(true);//Open homepage
        this.setVisible(false);
    }//GEN-LAST:event_menuhomepage1ActionPerformed

    private void menuadd1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuadd1ActionPerformed
        //Direct to create meal record page
        CreateRecord c = new CreateRecord();//Constructor and object c
        c.setVisible(true);//Open create page
        this.setVisible(false);
    }//GEN-LAST:event_menuadd1ActionPerformed

    private void menuview1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuview1ActionPerformed
        //Direct to view meal records page
        ViewRecord page = new ViewRecord();//Constructor and object page
        page.setVisible(true);//Open view page
        this.setVisible(false);
    }//GEN-LAST:event_menuview1ActionPerformed

    private void menuedit1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuedit1ActionPerformed
        //Direct to edit meal record page
        EditRecord c = new EditRecord();//Constructor and object c
        c.setVisible(true);//Open edit page
        this.setVisible(false);
    }//GEN-LAST:event_menuedit1ActionPerformed

    private void menudelete1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menudelete1ActionPerformed
        //Direct to delete meal record page
        DeleteRecord c = new DeleteRecord();//Constructor and object c
        c.setVisible(true);//Open delete page
        this.setVisible(false);
    }//GEN-LAST:event_menudelete1ActionPerformed

    private void menusearch1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menusearch1ActionPerformed
        //Direct to search meal record page
        SearchRecord c = new SearchRecord();//Constructor and object c
        c.setVisible(true);//Open search page
        this.setVisible(false);
    }//GEN-LAST:event_menusearch1ActionPerformed

    private void menuextras1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuextras1ActionPerformed
        //Direct to extras page
        Extras c = new Extras();//Constructor and object c
        c.setVisible(true);//Open search page
        this.setVisible(false);
    }//GEN-LAST:event_menuextras1ActionPerformed

    private void txtHeightActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtHeightActionPerformed
        f.add(txtHeight); //adding component in JFrame
    }//GEN-LAST:event_txtHeightActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Extras.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Extras.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Extras.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Extras.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Extras().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnResult;
    private javax.swing.JButton jButton6;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel lb1;
    private javax.swing.JLabel lb2;
    private javax.swing.JLabel lbResult;
    private javax.swing.JMenu menu1;
    private javax.swing.JMenuItem menuadd1;
    private javax.swing.JMenuBar menubar1;
    private javax.swing.JMenuItem menudelete1;
    private javax.swing.JMenuItem menuedit1;
    private javax.swing.JMenuItem menuextras1;
    private javax.swing.JMenuItem menuhomepage1;
    private javax.swing.JMenuItem menusearch1;
    private javax.swing.JMenuItem menuview1;
    private javax.swing.JTextField txtHeight;
    private javax.swing.JTextField txtWeight;
    // End of variables declaration//GEN-END:variables
}
