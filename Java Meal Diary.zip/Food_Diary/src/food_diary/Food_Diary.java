package food_diary;

/**
 *
 * @author geral
 */
public class Food_Diary {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
